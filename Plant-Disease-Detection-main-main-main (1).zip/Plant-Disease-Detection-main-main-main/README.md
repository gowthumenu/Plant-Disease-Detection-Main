# Plant-Disease-Detection-main-main
AI-driven Plant Disease Detection uses CNNs for real-time diagnosis, severity analysis, and supplement recommendations with e-commerce integration. Built with TensorFlow, OpenCV, and Flask. 🚀🌱
